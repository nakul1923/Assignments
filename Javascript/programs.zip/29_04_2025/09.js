function add(a,b){

    return a+b;
}

console.log(add(10,20));


// arrow function

var sum = (a,b)=>a+b;

console.log(sum(10,20));






var square = a=>a*a;

console.log(square(5));



// to upper case


var upper = str=>str.toUpperCase();

console.log(upper("deepika"));

