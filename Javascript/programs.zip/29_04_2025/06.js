function add(a){

    for(i=0;i<a.length;i++){

        a[i] = a[i] * a[i];
    }
}


var x = [10,20,30,40,50];
add(x);

console.log("result is "+ x);











// function add(a){

//     a= a*a;
// }


// x = 10;
// add(x);
// console.log("result is "+ a);

