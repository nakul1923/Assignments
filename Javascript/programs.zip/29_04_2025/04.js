function add(a,b){

    var c = a+b;
    console.log("Sum is " + c);

}

var x = Number(prompt("Enter value 1"));
var y = Number(prompt("Enter value 2"))
add(x,y);



// another method

function add(a,b){

    var c = a+b;
    console.log("Sum is " + c);

}

var x = Number(prompt("Enter value 1"));
var y = Number(prompt("Enter value 2"))
add(parseInt(x),parseInt(y));