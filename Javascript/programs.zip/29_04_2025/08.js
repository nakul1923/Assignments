var hello = function(){

    return "areeeee bhaiyyaa";
}

function lunch(x){

    console.log(x);
}

lunch(hello);