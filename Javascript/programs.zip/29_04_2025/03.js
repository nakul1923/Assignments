function add(a,b){

    var c = a+b;
    console.log("Sum is " + c);

}

add(100,200);
