var sum = function(a,b){

    c = a+b;
    return c;
}

var x = sum(100,200);
console.log(x);