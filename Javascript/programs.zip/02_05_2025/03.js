var student = {

    id: 101,
    name: "rashmika",
    marks: 99,
    address: "chennai"
}

console.log(student);

for(y in student){

    console.log(y);
    console.log(student[y]);
}