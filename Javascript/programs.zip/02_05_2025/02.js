var student = {

}

console.log(student);

student.id = 190;

student['name'] = 'rashmika';

console.log(student);