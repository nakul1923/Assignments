// program to implement object

var student = {

    id: 101,
    name: 'deepika',
    marks: 90
}

console.log(typeof(student))
console.log(student);

console.log(student.id);
console.log(student['name']);