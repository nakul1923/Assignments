
var a = [ 10,20,30,40];

console.log(a);

console.log(typeof(a));