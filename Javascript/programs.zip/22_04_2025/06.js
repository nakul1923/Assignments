var a = [[10,20,30,40],[50,60,70],[80,90]];

console.log(a[0][2]);

console.log(a[1][1]);

console.log(a[2][1]);