// array declaration types


var a = [];

var b = new Array();

console.log(a.length);
console.log(b.length);
