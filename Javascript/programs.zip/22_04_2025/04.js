// Array is heteregenous in javascript


var a = [10,null,true,"abc"];

var b = new Array();

b[0] = 10;
b[1] = "deepika";
b[2] = 12.5;
b[3] = true;

console.log(a)
