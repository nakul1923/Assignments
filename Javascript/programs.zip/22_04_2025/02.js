
var a = [ 10,20,30,40];

console.log(a);

console.log(a[0]);
console.log(a[1]);

