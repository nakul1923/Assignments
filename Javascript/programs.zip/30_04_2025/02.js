function sum(x,...n){

    console.log(x);
    console.log(n);
}

sum(1,2,3,4);

sum(99);

sum('abc',100,200,300,400);
