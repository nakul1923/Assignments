// Rest with default parameter.

function heyy(x,y='deepika',...n){

    console.log(x)
    console.log(y);
    console.log(n);
}

heyy('hello');
heyy('hello','rashmika');
heyy('hello','rashmika',2000,9000,70000);