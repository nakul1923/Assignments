// # IIFE (immidiately invoke function expression) - it is a javascript function that runs as soon as it is define


// (function(){

//     console.log("hello guys");
// })();




(()=>{

    console.log("hello guys");
})();