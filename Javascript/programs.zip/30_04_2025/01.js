// program to implement rest parameters


function sum(...n){

    console.log(n)
}

sum(1,2,3,4);

sum(99);



