// function done(){

//     console.log('done');
// }

// setTimeout(done,2000);






setTimeout(function(){

    console.log("done");
},2000);