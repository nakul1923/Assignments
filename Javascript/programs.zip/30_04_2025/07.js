console.log("starting");

setTimeout(()=>{console.log("areee timer")},2000);

console.log("ending");