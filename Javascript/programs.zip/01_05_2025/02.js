console.log(x);       // here gives error cannot access 'x'before  ini
let x =5 ;        