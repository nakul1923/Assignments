// hoisting

console.log(x);          // not giving error and printing undefined
var x = 5;         