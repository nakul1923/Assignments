var name1 = 'rashmika';
var name1 = 'deepika';

console.log(name1);