// in case of function expression and arrow functions hoisting will not be allow.

rr();

var rr = function hello(){

    console.log("hiiii");
}