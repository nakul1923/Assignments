let name1 = 'rashmika';    // here giver error because we cannot declare varible again with let keyword
let name1 = 'deepika';

console.log(name1);