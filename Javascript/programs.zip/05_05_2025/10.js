let str = "   hello       guys      ";

let str1 = str.trim();

console.log(str);
console.log(str1);
console.log(str.length);

console.log(str1.length);