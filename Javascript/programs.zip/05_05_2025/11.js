// comparing two strings

let str = new String("deepika");

let str1 = new String("wweepika");

console.log(str.localeCompare(str1));