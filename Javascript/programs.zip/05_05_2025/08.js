// multiline string

let str = `Hno 2656
            city indore`;

console.log(str);
            