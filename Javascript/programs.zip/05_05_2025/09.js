let str = 'hello guys';

console.log(str.charAt(3));
console.log(str.length());
console.log(str.includes("guys"));

let str1 = str.substring(5,9);
console.log(str1);